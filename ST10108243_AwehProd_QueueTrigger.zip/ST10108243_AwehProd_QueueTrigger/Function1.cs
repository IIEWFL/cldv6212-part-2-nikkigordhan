using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System.Text;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.Azure.Documents;
//calls the libraries that are needed.

namespace ST10108243_AwehProd_QueueTrigger
{
    public class QueueTrigger
    {
        [FunctionName("QueueTrigger")]
        public async void Run([QueueTrigger("vaccination-queue", Connection = "CONNECTION_STRING")]string myQueueItem, ILogger log)
        {
           try
           {
                string sEncodeMessage = Convert.ToBase64String(Encoding.UTF8.GetBytes(myQueueItem));
                // encodes the message to a 64 byte.
                    // the line of code was taken and adapted from StackOverflow.
                    // https://stackoverflow.com/questions/11743160/how-do-i-encode-and-decode-a-base64-string
                    // Zeigeist
                    // https://stackoverflow.com/users/2649698/zeigeist

                string[] messageParts = Encoding.UTF8.GetString(Convert.FromBase64String(sEncodeMessage)).Split(':');
                // seperates the string when ever there is a ':'.
                // the line of code above was taken and adapted from Microsoft Documenets.
                // https://learn.microsoft.com/en-us/dotnet/api/system.convert.frombase64string?view=net-7.0

                //assumptions

                //if else firt element is 13 or 10 then it first format else its the second format
                string sID = "";
                string sCenter = "";
                string sVaccination_Date = "";
                string sSerial_Number = "";

                
                    if (messageParts[0].Length == 13 || messageParts[0].Length == 10)
                    {
                       // format 1- Id:VaccinationCenter:VaccinationDate:VaccineSerialNumber
                        sID = messageParts[0];
                        sCenter = messageParts[1];
                        sVaccination_Date = messageParts[2];
                        sSerial_Number = messageParts[3];
                    }
                    else
                    {
                       // format 2- VaccineBarcode:VaccinationDate:VaccinationCenter:Id
                        sID = messageParts[3];
                        sCenter = messageParts[2];
                        sVaccination_Date = messageParts[1];
                        sSerial_Number = messageParts[0];
                    }
                // assigns the columns into the array elements.

                
                using (SqlConnection connection = new SqlConnection("Server=tcp:st10108243queuestorageserver.database.windows.net,1433;Initial Catalog=ST10108243QueueStorageDB;Persist Security Info=False;User ID=nikki;Password=CLDV6212PoEPart2;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"))
                {
                  

                    connection.Open();
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Messages (ID,Center,Vaccination_Date,Serial_Number) VALUES (@ID,@Center,@Vaccination_Date,@Serial_Number)";
                        command.Parameters.AddWithValue("@ID", sID);
                        command.Parameters.AddWithValue("@Center", sCenter);
                        command.Parameters.AddWithValue("@Vaccination_Date", sVaccination_Date);
                        command.Parameters.AddWithValue("@Serial_Number", sSerial_Number);
                        command.ExecuteNonQuery();
                        //adds the message to the SQL Database with the values corresponding to the table colunms.
                        // the code above was taken and adapted from StackOverflow.
                        // https://stackoverflow.com/questions/9155004/difference-with-parameters-add-and-parameters-addwithvalue
                        // John Woo
                        // https://stackoverflow.com/users/491243/john-woo
                    }
                }
                //PROCESS THE MESSAGE:
               // log.LogInformation($"Processing the message: {myQueueItem}");

                log.LogInformation($"Queue message has been stored successfully in the database ID = {sID}, Center = {sCenter}, Vaccination_Date = {sVaccination_Date}, Serial_Number = {sSerial_Number} ");
           }
           catch (Exception ex)
           {
                log.LogError($"Error in processing the queue message: {ex.Message}");
           }
        }
    }
}
